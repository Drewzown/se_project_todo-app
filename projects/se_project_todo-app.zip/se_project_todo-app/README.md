# Simple Todo App

Is available on moblie devices as well as web devices.
App is very simple.
## Functionality

Users can delete and add todo tasks. TODO App is simple web application. Check off tasks as they're completed, as well as add a due date to each task.

## Technology

1 JavaScript
2 Modules
3 CSS
4 HTML

## Deployment

This project is deployed on GitHub Pages:

- [Deployment Link](https://drewzown.github.io/se_project_todo-app/)
